package calcNumericoGUI.metodos;

import java.util.Locale;

public class MatrixUtils {

    public static double[][] copyMatrix(double[][] A) {
        int n = A.length;
        double[][] B = new double[n][n];
        for (int i = 0; i < n; i++)
            System.arraycopy(A[i], 0, B[i], 0, n);
        return B;
    }

    public static double[] copyVector(double[] v) {
        double[] nv = new double[v.length];
        System.arraycopy(v, 0, nv, 0, v.length);
        return nv;
    }

    public static String matrixToString(double[][] A) {
        StringBuilder sb = new StringBuilder();
        for (double[] row : A) {
            for (double v : row)
                sb.append(String.format(Locale.US, "%12.6f ", v));
            sb.append("\n");
        }
        return sb.toString();
    }

    public static String vectorToString(double[] v) {
        StringBuilder sb = new StringBuilder();
        for (double x : v)
            sb.append(String.format(Locale.US, "%12.6f ", x)).append("\n");
        return sb.toString();
    }

    public static double[] sub(double[] a, double[] b) {
        double[] r = new double[a.length];
        for (int i = 0; i < a.length; i++) r[i] = a[i] - b[i];
        return r;
    }

    public static double infNorm(double[] v) {
        double m = 0;
        for (double x : v) m = Math.max(m, Math.abs(x));
        return m;
    }
}
