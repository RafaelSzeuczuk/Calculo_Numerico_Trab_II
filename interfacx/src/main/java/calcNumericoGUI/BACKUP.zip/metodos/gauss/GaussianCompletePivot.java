package calcNumericoGUI.metodos.gauss;

import calcNumericoGUI.metodos.SolverResult;

public class GaussianCompletePivot {

    public static SolverResult solve(double[][] A, double[] b) {

        SolverResult res = new SolverResult();

        try {
            int n = A.length;

            double[][] M = new double[n][n];
            double[] v = new double[n];
            int[] perm = new int[n];

            for (int i = 0; i < n; i++) {
                System.arraycopy(A[i], 0, M[i], 0, n);
                v[i] = b[i];
                perm[i] = i;
            }

            for (int k = 0; k < n - 1; k++) {
                int p = k, q = k;
                double max = 0;
                for (int i = k; i < n; i++)
                    for (int j = k; j < n; j++)
                        if (Math.abs(M[i][j]) > max) {
                            max = Math.abs(M[i][j]);
                            p = i; q = j;
                        }

                double[] tmp = M[k]; M[k] = M[p]; M[p] = tmp;
                double tt = v[k]; v[k] = v[p]; v[p] = tt;

                for (int i = 0; i < n; i++) {
                    double aux = M[i][k];
                    M[i][k] = M[i][q];
                    M[i][q] = aux;
                }

                int pi = perm[k]; perm[k] = perm[q]; perm[q] = pi;

                for (int i = k + 1; i < n; i++) {
                    double m = M[i][k] / M[k][k];
                    for (int j = k; j < n; j++) M[i][j] -= m * M[k][j];
                    v[i] -= m * v[k];
                }
            }

            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--) {
                double sum = v[i];
                for (int j = i + 1; j < n; j++) sum -= M[i][j] * x[j];
                x[i] = sum / M[i][i];
            }

            double[] xf = new double[n];
            for (int i = 0; i < n; i++) xf[perm[i]] = x[i];

            res.solution = xf;
            res.message = "Gauss com pivoteamento completo concluído.";
            return res;

        } catch (Exception e) {
            res.message = "Erro: " + e.getMessage();
            return res;
        }
    }
}
