package calcNumericoGUI.metodos.gauss;

import calcNumericoGUI.metodos.SolverResult;

public class GaussianElimination {

    public static SolverResult solve(double[][] A, double[] b) {
        SolverResult res = new SolverResult();

        try {
            int n = A.length;
            double[][] M = new double[n][n];
            double[] v = new double[n];

            for (int i = 0; i < n; i++) {
                System.arraycopy(A[i], 0, M[i], 0, n);
                v[i] = b[i];
            }

            for (int k = 0; k < n - 1; k++) {
                if (Math.abs(M[k][k]) < 1e-15) {
                    res.message = "Zero na diagonal → impossível sem pivoteamento.";
                    return res;
                }
                for (int i = k + 1; i < n; i++) {
                    double m = M[i][k] / M[k][k];
                    for (int j = k; j < n; j++) M[i][j] -= m * M[k][j];
                    v[i] -= m * v[k];
                }
            }

            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--) {
                double sum = v[i];
                for (int j = i + 1; j < n; j++) sum -= M[i][j] * x[j];
                x[i] = sum / M[i][i];
            }

            res.solution = x;
            res.message = "Gauss direto concluído.";
            return res;

        } catch (Exception e) {
            res.message = "Erro: " + e.getMessage();
            return res;
        }
    }
}
