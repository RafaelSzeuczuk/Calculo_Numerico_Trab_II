package calcNumericoGUI.metodos.gauss;

import calcNumericoGUI.metodos.MatrixUtils;
import calcNumericoGUI.metodos.SolverResult;

import java.util.Locale;

public class GaussSeidel {

    public static SolverResult solve(double[][] Aorig, double[] borig, double tol,
                                     int maxIter, boolean showSteps, double[] x0, double omega) {

        SolverResult res = new SolverResult();
        try {
            int n = Aorig.length;
            double[][] A = MatrixUtils.copyMatrix(Aorig);
            double[] b = MatrixUtils.copyVector(borig);
            double[] x = MatrixUtils.copyVector(x0);

            StringBuilder steps = new StringBuilder();

            for (int iter = 1; iter <= maxIter; iter++) {
                double[] old = MatrixUtils.copyVector(x);

                for (int i = 0; i < n; i++) {
                    double s = b[i];
                    for (int j = 0; j < n; j++) if (j != i) s -= A[i][j] * x[j];
                    if (Math.abs(A[i][i]) < 1e-15) {
                        res.message = "Seidel: pivô ≈ 0 na linha " + (i + 1);
                        return res;
                    }
                    double newXi = s / A[i][i];
                    x[i] = (1 - omega) * x[i] + omega * newXi;
                }

                double diff = MatrixUtils.infNorm(MatrixUtils.sub(x, old));
                if (showSteps) steps.append(String.format(Locale.US, "Iter %d:\n%sDiff = %.10f\n\n", iter, MatrixUtils.vectorToString(x), diff));

                if (diff < tol) {
                    res.solution = x;
                    res.iterations = iter;
                    res.message = "Gauss–Seidel convergiu.";
                    res.steps = steps.toString();
                    return res;
                }
            }

            res.solution = x;
            res.iterations = maxIter;
            res.message = "Gauss–Seidel atingiu máximo de iterações.";
            res.steps = steps.toString();
            return res;

        } catch (Exception e) {
            res.message = "Erro: " + e.getMessage();
            return res;
        }
    }
}
