package calcNumericoGUI.metodos;

public class SolverResult {
    public double[] solution;
    public int iterations;
    public String message;
    public String steps;
}
