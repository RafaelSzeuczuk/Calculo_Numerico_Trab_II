package calcNumericoGUI.metodos.gauss;

import calcNumericoGUI.metodos.SolverResult;

public class GaussianPartialPivot {

    public static SolverResult solve(double[][] A, double[] b) {
        SolverResult res = new SolverResult();

        try {
            int n = A.length;

            double[][] M = new double[n][n];
            double[] v = new double[n];

            for (int i = 0; i < n; i++) {
                System.arraycopy(A[i], 0, M[i], 0, n);
                v[i] = b[i];
            }

            for (int k = 0; k < n - 1; k++) {
                int max = k;
                for (int i = k + 1; i < n; i++)
                    if (Math.abs(M[i][k]) > Math.abs(M[max][k])) max = i;

                double[] temp = M[k]; M[k] = M[max]; M[max] = temp;
                double tt = v[k]; v[k] = v[max]; v[max] = tt;

                for (int i = k + 1; i < n; i++) {
                    double m = M[i][k] / M[k][k];
                    for (int j = k; j < n; j++) M[i][j] -= m * M[k][j];
                    v[i] -= m * v[k];
                }
            }

            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--) {
                double sum = v[i];
                for (int j = i + 1; j < n; j++) sum -= M[i][j] * x[j];
                x[i] = sum / M[i][i];
            }

            res.solution = x;
            res.message = "Gauss com pivoteamento parcial concluído.";
            return res;

        } catch (Exception e) {
            res.message = "Erro: " + e.getMessage();
            return res;
        }
    }
}
