package calcNumericoGUI.controllers;

import calcNumericoGUI.metodos.MatrixUtils;
import calcNumericoGUI.metodos.SolverResult;
import calcNumericoGUI.metodos.gauss.Cholesky;
import calcNumericoGUI.metodos.gauss.GaussianCompletePivot;
import calcNumericoGUI.metodos.gauss.GaussianElimination;
import calcNumericoGUI.metodos.gauss.GaussianPartialPivot;
import calcNumericoGUI.metodos.gauss.Jacobi;
import calcNumericoGUI.metodos.gauss.LU;
import calcNumericoGUI.metodos.gauss.GaussSeidel;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.Priority;
import javafx.scene.layout.Region;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Locale;

/**
 * Controller para o Capítulo 3 - Sistemas Lineares.
 * Gera dinamicamente uma grade com A|b|x0.
 */
public class Capitulo3Controller {

    @FXML private Spinner<Integer> spinnerN;
    @FXML private ChoiceBox<String> choiceMetodo;
    @FXML private GridPane gridMatrix;
    @FXML private TextField tfTolerance;
    @FXML private TextField tfMaxIter;
    @FXML private TextField tfOmega;
    @FXML private CheckBox cbShowSteps;
    @FXML private CheckBox cbAutoPermute;
    @FXML private TextArea taOutput;

    private TextField[][] matrixFields;
    private TextField[] vectorFields;
    private TextField[] x0Fields;

    @FXML
    public void initialize() {
        spinnerN.setValueFactory(new SpinnerValueFactory.IntegerSpinnerValueFactory(1, 10, 3));
        spinnerN.setEditable(true);

        choiceMetodo.getItems().clear();
        choiceMetodo.getItems().addAll(
                "Eliminação de Gauss (sem pivoteamento)",
                "Gauss com pivoteamento parcial",
                "Gauss com pivoteamento completo",
                "Fatoração LU (Doolittle)",
                "Fatoração de Cholesky",
                "Gauss-Jacobi (iterativo)",
                "Gauss-Seidel (iterativo)"
        );
        choiceMetodo.getSelectionModel().selectFirst();

        choiceMetodo.getSelectionModel().selectedItemProperty().addListener((obs,oldv,newv) -> {
            adaptarCamposParaMetodo(newv);
        });

        gerarGrade(null);

        Platform.runLater(() -> adaptarCamposParaMetodo(choiceMetodo.getSelectionModel().getSelectedItem()));
    }

    private void adaptarCamposParaMetodo(String metodo) {
        boolean isIterativo = metodo != null && (metodo.contains("Jacobi") || metodo.contains("Seidel"));
        boolean isCholesky = metodo != null && metodo.toLowerCase().contains("cholesky");
        boolean isDireto = !isIterativo; // Métodos diretos não precisam de tolerância

        // Habilita/desabilita campos baseado no tipo de método
        tfTolerance.setDisable(!isIterativo);
        tfMaxIter.setDisable(!isIterativo);
        tfOmega.setDisable(!(metodo != null && metodo.contains("Seidel")));

        // Define valores padrão para métodos não iterativos
        if (isDireto) {
            tfTolerance.setText("0.0001"); // Valor padrão, mas não será usado
        } else {
            tfTolerance.setText("0.0001"); // Valor padrão para iterativos
        }

        // x0 fields only relevant for iterativos
        if (x0Fields != null) {
            for (TextField tf : x0Fields) tf.setDisable(!isIterativo);
        }

        // show quick hints
        taOutput.appendText("Selecionado: " + metodo + "\n");
        if (isCholesky) taOutput.appendText("Cholesky: checa simetria e definicao positiva.\n");
        if (isIterativo) taOutput.appendText("Método iterativo: informe x⁰ (coluna à direita) se quiser.\n");
        if (isDireto) taOutput.appendText("Método direto: tolerância não é necessária.\n");
    }

    @FXML
    public void voltar(ActionEvent event) throws IOException {
        Node node = (Node) event.getSource();
        Stage stage = (Stage) node.getScene().getWindow();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/calcNumericoGUI/views/tela_principal.fxml"));
        stage.getScene().setRoot(loader.load());
    }

    @FXML
    public void gerarGrade(ActionEvent event) {
        int n = spinnerN.getValue();
        gridMatrix.getChildren().clear();
        matrixFields = new TextField[n][n];
        vectorFields = new TextField[n];
        x0Fields = new TextField[n];

        // cabeçalho
        for (int j = 0; j < n; j++) {
            Label lbl = new Label("a" + (1) + "," + (j + 1));
            GridPane.setConstraints(lbl, j, 0);
            gridMatrix.getChildren().add(lbl);
        }
        Label lblB = new Label("b");
        GridPane.setConstraints(lblB, n, 0);
        gridMatrix.getChildren().add(lblB);
        Label lblX0 = new Label("x⁰");
        GridPane.setConstraints(lblX0, n + 1, 0);
        gridMatrix.getChildren().add(lblX0);

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                TextField tf = new TextField();
                tf.setPrefWidth(100);
                tf.setPromptText("0");
                matrixFields[i][j] = tf;
                GridPane.setConstraints(tf, j, i + 1);
                gridMatrix.getChildren().add(tf);
                GridPane.setHgrow(tf, Priority.ALWAYS);
            }
            TextField tfB = new TextField();
            tfB.setPrefWidth(100);
            tfB.setPromptText("0");
            vectorFields[i] = tfB;
            GridPane.setConstraints(tfB, n, i + 1);
            gridMatrix.getChildren().add(tfB);

            TextField tfx0 = new TextField();
            tfx0.setPrefWidth(100);
            tfx0.setPromptText("x" + (i + 1) + "⁰");
            x0Fields[i] = tfx0;
            GridPane.setConstraints(tfx0, n + 1, i + 1);
            gridMatrix.getChildren().add(tfx0);
        }

        gridMatrix.setMinWidth(Region.USE_PREF_SIZE);
    }

    @FXML
    public void preencherZeros(ActionEvent event) {
        if (matrixFields == null) return;
        for (int i = 0; i < matrixFields.length; i++) {
            for (int j = 0; j < matrixFields.length; j++) matrixFields[i][j].setText("0");
            vectorFields[i].setText("0");
            x0Fields[i].setText("0");
        }
    }

    private double[][] lerMatrizA() throws NumberFormatException {
        int n = matrixFields.length;
        double[][] A = new double[n][n];
        for (int i = 0; i < n; i++) for (int j = 0; j < n; j++) {
            String s = matrixFields[i][j].getText();
            if (s == null || s.trim().isEmpty()) s = "0";
            A[i][j] = Double.parseDouble(s.trim());
        }
        return A;
    }

    private double[] lerVetorB() throws NumberFormatException {
        int n = vectorFields.length;
        double[] b = new double[n];
        for (int i = 0; i < n; i++) {
            String s = vectorFields[i].getText();
            if (s == null || s.trim().isEmpty()) s = "0";
            b[i] = Double.parseDouble(s.trim());
        }
        return b;
    }

    private double[] lerX0() {
        int n = x0Fields.length;
        double[] x0 = new double[n];
        for (int i = 0; i < n; i++) {
            String s = x0Fields[i].getText();
            if (s == null || s.trim().isEmpty()) s = "0";
            try {
                x0[i] = Double.parseDouble(s.trim());
            } catch (NumberFormatException e) {
                x0[i] = 0.0;
            }
        }
        return x0;
    }

    @FXML
    public void limparTudo(ActionEvent event) {
        taOutput.clear();
        if (matrixFields == null) return;
        for (int i = 0; i < matrixFields.length; i++) {
            for (int j = 0; j < matrixFields.length; j++) matrixFields[i][j].clear();
            vectorFields[i].clear();
            x0Fields[i].clear();
        }
    }

    @FXML
    public void executarMetodo(ActionEvent event) {
        try {
            double[][] A = lerMatrizA();
            double[] b = lerVetorB();
            double[] x0 = lerX0();
            String metodo = choiceMetodo.getSelectionModel().getSelectedItem();

            boolean isIterativo = metodo.contains("Jacobi") || metodo.contains("Seidel");

            // Para métodos iterativos, ler tolerância e maxIter
            double tol = isIterativo ? Double.parseDouble(tfTolerance.getText().trim()) : 0.0;
            int maxIter = isIterativo ? Integer.parseInt(tfMaxIter.getText().trim()) : 0;
            double omega = 1.0;

            if (metodo.contains("Seidel")) {
                try {
                    omega = Double.parseDouble(tfOmega.getText().trim());
                } catch (Exception ignored) {}
            }

            taOutput.clear();
            taOutput.appendText("Executando: " + metodo + "\n");

            SolverResult result = null;
            long t0 = System.nanoTime();

            switch (metodo) {
                case "Eliminação de Gauss (sem pivoteamento)":
                    result = GaussianElimination.solve(A, b);
                    break;
                case "Gauss com pivoteamento parcial":
                    result = GaussianPartialPivot.solve(A, b);
                    break;
                case "Gauss com pivoteamento completo":
                    result = GaussianCompletePivot.solve(A, b);
                    break;
                case "Fatoração LU (Doolittle)":
                    result = LU.factorSolve(A, b);
                    break;
                case "Fatoração de Cholesky":
                    result = Cholesky.factorSolve(A, b);
                    break;
                case "Gauss-Jacobi (iterativo)":
                    result = Jacobi.solve(A, b, tol, maxIter, cbShowSteps.isSelected(), x0);
                    break;
                case "Gauss-Seidel (iterativo)":
                    result = GaussSeidel.solve(A, b, tol, maxIter, cbShowSteps.isSelected(), x0, omega);
                    break;
                default:
                    taOutput.appendText("Método não implementado.\n");
                    return;
            }

            long t1 = System.nanoTime();
            double elapsedMs = (t1 - t0) / 1e6;

            if (result == null) {
                taOutput.appendText("Resultado nulo.\n");
                return;
            }
            taOutput.appendText("Mensagem: " + result.message + "\n");
            if (result.solution != null) {
                taOutput.appendText("Solução:\n");
                for (int i = 0; i < result.solution.length; i++)
                    taOutput.appendText(String.format(Locale.US, "x[%d] = %.12f\n", i + 1, result.solution[i]));
            }
            if (result.iterations > 0) taOutput.appendText("Iterações: " + result.iterations + "\n");
            taOutput.appendText(String.format(Locale.US, "Tempo (ms): %.4f\n", elapsedMs));
            if (cbShowSteps.isSelected() && result.steps != null && !result.steps.isEmpty()) {
                taOutput.appendText("\nPASSO A PASSO:\n");
                taOutput.appendText(result.steps);
            }
        } catch (NumberFormatException ex) {
            taOutput.appendText("Erro na leitura de números: " + ex.getMessage() + "\n");
        } catch (Exception ex) {
            taOutput.appendText("Erro: " + ex.getMessage() + "\n");
            ex.printStackTrace();
        }
    }
}