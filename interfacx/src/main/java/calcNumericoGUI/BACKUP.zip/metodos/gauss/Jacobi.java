package calcNumericoGUI.metodos.gauss;

import calcNumericoGUI.metodos.MatrixUtils;
import calcNumericoGUI.metodos.SolverResult;

import java.util.Locale;

public class Jacobi {

    public static SolverResult solve(double[][] Aorig, double[] borig, double tol,
                                     int maxIter, boolean showSteps, double[] x0) {

        SolverResult res = new SolverResult();
        try {
            int n = Aorig.length;
            double[][] A = MatrixUtils.copyMatrix(Aorig);
            double[] b = MatrixUtils.copyVector(borig);

            double[] x = MatrixUtils.copyVector(x0);
            double[] xNew = new double[n];

            StringBuilder steps = new StringBuilder();

            for (int iter = 1; iter <= maxIter; iter++) {

                for (int i = 0; i < n; i++) {
                    double s = b[i];
                    for (int j = 0; j < n; j++) if (j != i) s -= A[i][j] * x[j];
                    if (Math.abs(A[i][i]) < 1e-15) {
                        res.message = "Jacobi: pivô ≈ 0 na linha " + (i + 1);
                        return res;
                    }
                    xNew[i] = s / A[i][i];
                }

                double diff = MatrixUtils.infNorm(MatrixUtils.sub(xNew, x));

                if (showSteps) steps.append(String.format(Locale.US, "Iter %d:\n%sDiff = %.10f\n\n", iter, MatrixUtils.vectorToString(xNew), diff));

                System.arraycopy(xNew, 0, x, 0, n);

                if (diff < tol) {
                    res.solution = x;
                    res.iterations = iter;
                    res.message = "Jacobi convergiu.";
                    res.steps = steps.toString();
                    return res;
                }
            }

            res.solution = x;
            res.iterations = maxIter;
            res.message = "Jacobi atingiu o máximo de iterações.";
            res.steps = steps.toString();
            return res;

        } catch (Exception e) {
            res.message = "Erro: " + e.getMessage();
            return res;
        }
    }
}
