package calcNumericoGUI.metodos.gauss;

import calcNumericoGUI.metodos.MatrixUtils;
import calcNumericoGUI.metodos.SolverResult;

public class Cholesky {

    public static SolverResult factorSolve(double[][] Aorig, double[] borig) {

        SolverResult res = new SolverResult();
        try {
            int n = Aorig.length;

            // checar simetria
            for (int i = 0; i < n; i++)
                for (int j = i + 1; j < n; j++)
                    if (Math.abs(Aorig[i][j] - Aorig[j][i]) > 1e-12) {
                        res.message = "Erro: matriz NÃO é simétrica → Cholesky não permitido.";
                        return res;
                    }

            double[][] A = MatrixUtils.copyMatrix(Aorig);
            double[][] L = new double[n][n];
            double[] b = MatrixUtils.copyVector(borig);

            for (int i = 0; i < n; i++) {
                for (int j = 0; j <= i; j++) {
                    double sum = 0;
                    for (int k = 0; k < j; k++) sum += L[i][k] * L[j][k];
                    if (i == j) {
                        double val = A[i][i] - sum;
                        if (val <= 0) {
                            res.message = "Cholesky falhou: matriz NÃO é definida positiva.";
                            return res;
                        }
                        L[i][i] = Math.sqrt(val);
                    } else {
                        L[i][j] = (A[i][j] - sum) / L[j][j];
                    }
                }
            }

            double[] y = new double[n];
            for (int i = 0; i < n; i++) {
                double s = b[i];
                for (int j = 0; j < i; j++) s -= L[i][j] * y[j];
                y[i] = s / L[i][i];
            }

            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--) {
                double s = y[i];
                for (int j = i + 1; j < n; j++) s -= L[j][i] * x[j];
                x[i] = s / L[i][i];
            }

            res.solution = x;
            res.message = "Cholesky concluído.";
            return res;

        } catch (Exception e) {
            res.message = "Erro: " + e.getMessage();
            return res;
        }
    }
}
