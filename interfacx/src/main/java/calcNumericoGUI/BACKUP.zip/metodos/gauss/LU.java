package calcNumericoGUI.metodos.gauss;

import calcNumericoGUI.metodos.SolverResult;

public class LU {

    public static SolverResult factorSolve(double[][] Aorig, double[] borig) {

        SolverResult res = new SolverResult();

        try {
            int n = Aorig.length;

            double[][] L = new double[n][n];
            double[][] U = new double[n][n];

            double[][] A = new double[n][n];
            for (int i = 0; i < n; i++) System.arraycopy(Aorig[i], 0, A[i], 0, n);

            for (int i = 0; i < n; i++) L[i][i] = 1;

            for (int j = 0; j < n; j++) {
                for (int i = 0; i <= j; i++) {
                    double sum = 0;
                    for (int k = 0; k < i; k++) sum += L[i][k] * U[k][j];
                    U[i][j] = A[i][j] - sum;
                }
                for (int i = j + 1; i < n; i++) {
                    double sum = 0;
                    for (int k = 0; k < j; k++) sum += L[i][k] * U[k][j];
                    L[i][j] = (A[i][j] - sum) / U[j][j];
                }
            }

            double[] y = new double[n];
            for (int i = 0; i < n; i++) {
                double s = borig[i];
                for (int j = 0; j < i; j++) s -= L[i][j] * y[j];
                y[i] = s;
            }

            double[] x = new double[n];
            for (int i = n - 1; i >= 0; i--) {
                double s = y[i];
                for (int j = i + 1; j < n; j++) s -= U[i][j] * x[j];
                x[i] = s / U[i][i];
            }

            res.solution = x;
            res.message = "Fatoração LU concluída.";
            return res;

        } catch (Exception e) {
            res.message = "Erro: " + e.getMessage();
            return res;
        }
    }
}
